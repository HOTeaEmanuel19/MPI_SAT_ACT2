#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <set>
#include <string>
#include <algorithm>
#include <chrono>

using namespace std;
//Limita maxima de clauze dupa care oprim programul
const int LIM_CL=10000;
int nr_clauze;
double memorie_MB(const vector<set<int>>& formula) {
    double total = 0;
    for (const auto& clauza : formula)
        total += sizeof(clauza) + clauza.size() * sizeof(int);
    total += sizeof(formula) + formula.capacity() * sizeof(set<int>);
    return total/(1024.0*1024.0);
}

void citire_din_fisier(vector<set<int>>&formula) {
    string nume_fisier;
    cout<<"Introdu numele fisierului testului in format DIMACS:\n";
    cin>>nume_fisier;
    ifstream fin(nume_fisier);
    if(!fin.is_open()) {
        cerr<<"Nu s-a putut deschide fisierul:"<<nume_fisier<<endl;
        return;
    }
     int num_vars = 0, n = 0;
string line;
    // Sărim peste comentarii și citim linia 'p cnf'
    while (getline(fin, line)) {
        // Ignorăm comentariile
        if (line[0] == 'c') {
            continue;
        }
        // Procesăm linia de header (p cnf)
        if (line.substr(0, 5) == "p cnf") {
            istringstream iss(line);
            string p, cnf;
            iss >> p >> cnf >> num_vars >> n;
            break;  // Am citit headerul, continuăm cu clauzele
        }
    }
    for(int i=0;i<n;++i) {
        string line;
        getline(fin,line);
        stringstream ss(line);
        set<int> clauza;
        int literal;
        while(ss>>literal) {
            if(literal==0) break;
            clauza.insert(literal);
        }
        if(!clauza.empty())
            formula.push_back(clauza);
    }
    fin.close();
}

bool obtine_clauza_noua(const set<int>& a,const set<int>& b,int& x)
{
    set<int> literali_opusi;
    for (int lit:a)
        if (b.count(-lit))
            literali_opusi.insert(lit);
    if (literali_opusi.size()!=1) return false;
    x=*literali_opusi.begin();
    return true;
}

set<int> aduna_clauze(const set<int>& a,const set<int>& b,int lit)
{
    set<int> rez(a);
    rez.insert(b.begin(),b.end());
    rez.erase(lit);
    rez.erase(-lit);
    return rez;
}

bool avem_clauza_unitara(const vector<set<int>>& formula)
{
    for (const auto& clauza:formula)
        if (clauza.size()==1) return true;
    return false;
}

bool avem_literal_pur(const vector<set<int>>& formula)
{
    set<int> literali;
    for (const auto& clauza:formula)
        for (int lit:clauza)
            literali.insert(lit);
            //Verifica daca avem literal pur, opusul acestuia nu trebuie sa se afle in set
    for (int lit:literali)
        if (!literali.count(-lit)) return true;
    return false;
}

vector<set<int>> rezolutie(vector<set<int>>& formula)
{
    //Rezolutie
    while (true)
    {
        vector<set<int>> clauze_noi;
        int siz=formula.size();
        for (int i=0;i<siz;i++)
        {
            for (int j=i+1;j<siz;j++)
            {
                int lit;
                if (obtine_clauza_noua(formula[i],formula[j],lit))
                {
                    set<int> rezolvent=aduna_clauze(formula[i],formula[j],lit);
                    if (rezolvent.empty()) return formula;
                    bool exista=false;
                    for (const auto& clauza:formula)
                    {
                        if (clauza==rezolvent)
                        {
                            exista=true;
                            break;
                        }
                    }
                    if (!exista)
                    {
                        nr_clauze++;
                            if(nr_clauze>LIM_CL)
                            {
                                cout<<"Limita de clauze a fost depasita\n";
                                return {};
                            }
                        clauze_noi.push_back(rezolvent);
                        formula.push_back(rezolvent);
                    }
                }
            }
        }
        if (clauze_noi.empty()) return formula;
    }
}

vector<set<int>> propagarea_unitatii(vector<set<int>>& formula)
{
    //Creaza vectorul de clauze unitare
    vector<int> clauze_unitare;
    for (const auto& clauza:formula)
        if (clauza.size()==1)
            clauze_unitare.push_back(*clauza.begin());
//ELimina clauzele care sunt unitare si opusul literalului din celelalte
    for (int u:clauze_unitare)
    {
        for (auto it=formula.begin();it!=formula.end();)
        {
            if (it->count(u)) it=formula.erase(it);
            else ++it;
        }
        for (auto& clauza:formula)
            clauza.erase(-u);
    }
    return formula;
}

vector<set<int>> elimina_literal_pur(vector<set<int>>& formula)
{
    set<int> literali;
    for (const auto& clauza:formula)
        for (int lit:clauza)
            literali.insert(lit);

    set<int> puri;
    for (int lit:literali)
        if (!literali.count(-lit))
            puri.insert(lit);
//Elimina clauzele ce contin literalii puri
    for (auto it=formula.begin();it!=formula.end();)
    {
        bool sters=false;
        for (int p:puri)
            if (it->count(p))
            {
                it=formula.erase(it);
                sters=true;
                break;
            }
        if (!sters) ++it;
    }
    return formula;
}

bool contine_clauza_vida(const vector<set<int>>& formula)
{
    for (const auto& clauza:formula)
        if (clauza.empty()) return true;
    return false;
}

bool davis_putnam(vector<set<int>> formula)
{
    while (true)
    {//Aplicam regula de eliminare a clauzelor unitare
        formula=propagarea_unitatii(formula);
        if (formula.empty()) return true;
        if (contine_clauza_vida(formula)) return false;
//Aplicam regula literalului pur
        formula=elimina_literal_pur(formula);
        if (formula.empty()) return true;
//Continua cu rezolutia dacc nu am obtinut multimea vida de clauze
        size_t dim=formula.size();
        formula=rezolutie(formula);
        if (formula.size()==dim) return true;
    }
}

int main()
{cout<<"-- Algoritmul DP --\n";
    vector<set<int>> formula;
    citire_din_fisier(formula);

    auto start=chrono::high_resolution_clock::now();

    if (davis_putnam(formula) && nr_clauze<=LIM_CL) cout<<"SAT\n";
    else if(nr_clauze>LIM_CL) cout<<"Prea multe clauze!!!\n";
    else cout<<"NESAT\n";
    auto end=chrono::high_resolution_clock::now();
    chrono::duration<double> durata=end-start;
    cout<<"Timp executie: "<<durata.count()<<"s\n";
 cout<<"Clauze generate:" <<nr_clauze<<'\n';
cout<<"Memorie consumata:"<<memorie_MB(formula)<<"MB";
    return 0;
}
