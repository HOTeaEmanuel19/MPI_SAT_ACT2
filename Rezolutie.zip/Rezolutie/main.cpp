#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <set>
#include <string>
#include <algorithm>
#include <chrono>

using namespace std;
//Limita maxima de clauze dupa care oprim programul
const int LIM_CL=10000;
int nr_clauze;
double memorie_MB(const vector<set<int>>& formula) {
    double total = 0;
    for (const auto& clauza : formula)
        total += sizeof(clauza) + clauza.size() * sizeof(int);
    total += sizeof(formula) + formula.capacity() * sizeof(set<int>);
    return total/(1024.0*1024.0);
}

void citire_din_fisier(vector<set<int>>&formula) {
    string nume_fisier;
    cout<<"Introdu numele fisierului testului in format DIMACS:\n";
    cin>>nume_fisier;
    ifstream fin(nume_fisier);
    if(!fin.is_open()) {
        cerr<<"Nu s-a putut deschide fisierul:"<<nume_fisier<<endl;
        return;
    }
     int num_vars = 0, n = 0;
string line;
    // Sărim peste comentarii și citim linia 'p cnf'
    while (getline(fin, line)) {
        // Ignorăm comentariile
        if (line[0] == 'c') {
            continue;
        }
        // Procesăm linia de header (p cnf)
        if (line.substr(0, 5) == "p cnf") {
            istringstream iss(line);
            string p, cnf;
            iss >> p >> cnf >> num_vars >> n;
            break;  // Am citit headerul, continuăm cu clauzele
        }
    }
    for(int i=0;i<n;++i) {
        string line;
        getline(fin,line);
        stringstream ss(line);
        set<int> clauza;
        int literal;
        while(ss>>literal) {
            if(literal==0) break;
            clauza.insert(literal);
        }
        if(!clauza.empty())
            formula.push_back(clauza);
    }
    fin.close();
}

bool obtine_clauza_noua(const set<int>&a,const set<int>&b,int&x) {
    set<int> literali_opusi;
    for(int lit:a)
        if(b.count(-lit))
            literali_opusi.insert(lit);
    if(literali_opusi.size()!=1) return false;
    x=*literali_opusi.begin();
    return true;
}

set<int> aduna_clauze(const set<int>&a,const set<int>&b,int lit) {
    set<int> rez(a);
    rez.insert(b.begin(),b.end());
    rez.erase(lit);
    rez.erase(-lit);
    //Aduna clauze eliminand perechea de literal cu opusul
    return rez;
}
bool rezolutie(vector<set<int>>&formula) {
    while(true) {
        vector<set<int>> clauze_noi;
        int siz=formula.size();
        for(int i=0;i<siz;i++) {
            for(int j=i+1;j<siz;j++) {
                int lit;
                if(obtine_clauza_noua(formula[i],formula[j],lit)) { //daca gasim clauza noua
                    set<int> rezolvent=aduna_clauze(formula[i],formula[j],lit);
                    if(rezolvent.empty()) return false; // clauza vidã => NESAT
                    bool exista=false;
                    for(const auto& clauza:formula) {
                        if(clauza==rezolvent) {
                            exista=true;
                            break;
                        }
                    }
                    if(!exista) {
                            nr_clauze++;
                            if(nr_clauze>LIM_CL)
                            {
                                cout<<"Limita de clauze a fost depasita\n";
                                return false;
                            }
                        clauze_noi.push_back(rezolvent);
                        formula.push_back(rezolvent);
                    }
                }
            }
        }
        if(clauze_noi.empty()) return true; // nu se pot genera clauze noi => SAT
    }


}

int main() {
    cout<<"-- Algoritmul de Rezolutie --\n";
    vector<set<int>> formula;
    citire_din_fisier(formula);
    auto start=chrono::high_resolution_clock::now();
    if(rezolutie(formula))
        cout<<"SAT\n";
    else
        if(nr_clauze<=LIM_CL)
            cout<<"NESAT\n";

    auto end=chrono::high_resolution_clock::now();
    chrono::duration<double> durata=end-start;
    cout<<"Timp executie:"<<durata.count()<<"s\n";
     cout<<"Clauze generate:" <<nr_clauze<<'\n';
     cout<<"Memorie consumata:"<<memorie_MB(formula)<<"MB";
    return 0;
}
