#include<iostream>
#include<vector>
#include<fstream>
#include<sstream>
#include<set>
#include<string>
#include<unordered_map>
#include<cmath>
#include<ctime>
using namespace std;
int nr_ramificari;
const int nrMax_ramificari=100000;
void citire_din_fisier(vector<set<int>>&formula) {
    string nume_fisier;
    cout<<"Introdu numele fisierului testului in format DIMACS:\n";
    cin>>nume_fisier;
    ifstream fin(nume_fisier);
    if(!fin.is_open()) {
        cerr<<"Nu s-a putut deschide fisierul:"<<nume_fisier<<endl;
        return;
    }
     int num_vars = 0, n = 0;
string line;
    // Sărim peste comentarii și citim linia 'p cnf'
    while (getline(fin, line)) {
        // Ignorăm comentariile
        if (line[0] == 'c') {
            continue;
        }
        // Procesăm linia de header (p cnf)
        if (line.substr(0, 5) == "p cnf") {
            istringstream iss(line);
            string p, cnf;
            iss >> p >> cnf >> num_vars >> n;
            break;  // Am citit headerul, continuăm cu clauzele
        }
    }
    for(int i=0;i<n;++i) {
        string line;
        getline(fin,line);
        stringstream ss(line);
        set<int> clauza;
        int literal;
        while(ss>>literal) {
            if(literal==0) break;
            clauza.insert(literal);
        }
        if(!clauza.empty())
            formula.push_back(clauza);
    }
    fin.close();
}

bool avem_clauza_unitara(vector<set<int>> formula){
    if(formula.empty())return false;
    for(auto i:formula)
        if(i.size()==1)return true;
    return false;
}

bool avem_literal_pur(vector<set<int>> formula){
    set<int> literali;
    for(auto i:formula)
        for(auto j:i)
            literali.insert(j);
    for(auto i:literali)
        if(literali.find(-i)==literali.end())return true;
    return false;
}

vector<set<int>> propagarea_unitatii(vector<set<int>> formula,int &clauza_vida){
    //ELiminam clauzele unitare si opusul lor din celelalte
    vector<int> unitare;
    for(auto i:formula)
        if(i.size()==1)unitare.push_back(*i.begin());
    for(auto i:unitare){
        for(auto it=formula.begin();it<formula.end();){
            if(it->count(i))it=formula.erase(it);
            else it++;
        }
        //Stergem opusul din celelalte
        for(auto it=formula.begin();it<formula.end();){
            if(it->count(-i)){
                it->erase(-i);
                if(it->empty()){clauza_vida=1;break;}
            }else it++;
        }
    }
    return formula;
}

vector<set<int>> literal_pur(vector<set<int>> formula){
    //Aplicam regula literalilor puri
    set<int> literali,puri;
    for(auto i:formula)
        for(auto j:i)
            literali.insert(j);
    //Crem setul de literali puri
    for(auto i:literali)
        if(literali.find(-i)==literali.end())puri.insert(i);
        //Eliminam clauzele ce contin literali puri
    for(auto it=formula.begin();it<formula.end();){
        bool sters=0;
        for(auto i:puri)
            if(it->count(i)){it=formula.erase(it);
            sters=1;
            break;}
        if(!sters)it++;
    }
    return formula;
}

bool verifica_clauza_vida(vector<set<int>> formula){
    for(auto i:formula)
        if(i.empty())return true;
    return false;
}

int heuristica_frecventa(vector<set<int>> formula){
    //Alegem literalul care apare cel mai des
    unordered_map<int,int> cnt;
    int max_frec=0,lit=0;
    for(auto i:formula)
        for(auto j:i){
            cnt[j]++;
            if(cnt[j]>max_frec){
                max_frec=cnt[j];
                lit=j;
            }
        }
    return lit;
}

int heuristica_scurta(vector<set<int>> formula){
    //Alegem primul literal din clauza cea mai scurta si consideram ca toate clauzele au mai putin de 100000 de literali
    int min_dim=100000,lit=0;
    for(auto i:formula){
        if(i.size()<min_dim){
            min_dim=i.size();
            lit=*i.begin();
        }
    }
    return lit;
}

int heuristica_jw(vector<set<int>> formula){
    //Fiecarei variabile i se atribuie un scor si cea cu scorul maxim este ales dupa formula jw
    unordered_map<int,double> scor;
    for(auto clauza:formula)
        for(auto lit:clauza)
            scor[lit]+=pow(2.0,-(int)clauza.size());
    int literal_max=0;
    double max_scor=-1;
    for(unordered_map<int,double>::iterator it=scor.begin();it!=scor.end();++it)
        if(it->second>max_scor){
            max_scor=it->second;
            literal_max=it->first;
        }
    return literal_max;
}

int alege_literal(vector<set<int>> formula,string heuristica){
    if(heuristica=="frecventa")return heuristica_frecventa(formula);
    if(heuristica=="scurta")return heuristica_scurta(formula);
    return heuristica_jw(formula);
}

bool dpll(vector<set<int>> formula,string heuristica){
    int clauza_vida=0;
    //Aplica regula propagarii unitatii
    while(!clauza_vida&&avem_clauza_unitara(formula))
        formula=propagarea_unitatii(formula,clauza_vida);
        //Daca obtinem multimea vida de clauze atunci ne oprim,e SAT

    if(formula.empty())return true;
    if(verifica_clauza_vida(formula))return false;
    //Aplicam regula literalului pur

    while(avem_literal_pur(formula)&&!formula.empty())
        formula=literal_pur(formula);
        //Verificam dinou
    if(formula.empty())return true;
    //Se alege heuristica
    int lit=alege_literal(formula,heuristica);
    //Se ramifica problema,adaugand literalul ales la multimea de clauze
    auto f1=formula;
    f1.push_back({lit});
    auto f2=formula;
    f2.push_back({-lit});
    nr_ramificari++;
    if(nr_ramificari>nrMax_ramificari) return false;
   //Incearca fiecare ramura folosind backtracking
    return dpll(f1,heuristica)||dpll(f2,heuristica);
}

int main(){
    cout<<"-- Algoritmul DPLL --\n";
    vector<set<int>> formula;
    string heuristica;
citire_din_fisier(formula);
 cout<<"Alege heuristica (frecventa/scurta/jw): ";
    cin>>heuristica;
    clock_t start=clock();
    if(dpll(formula,heuristica) && nr_ramificari<=nrMax_ramificari)cout<<"SAT\n";
    else if(nr_ramificari>nrMax_ramificari) cout<<"Limita de ramificari a fost depasita\n";
    else cout<<"NESAT\n";
    clock_t end=clock();
    cout<<"Timp: ";
    cout<<(double)(end-start)/CLOCKS_PER_SEC<<'s'<<'\n';
    cout<<"Numar ramificari: " <<nr_ramificari<<'\n';
    return 0;
}
